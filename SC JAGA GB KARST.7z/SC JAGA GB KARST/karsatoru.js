
// Fungsi untuk mengecek apakah pengirim adalah owner
function isOwner(sender) {
    // Ganti dengan nomor owner Anda (format: 6281234567890@c.us)
    const ownerNumber = '6281234567890@c.us'; 
    return sender === ownerNumber;
}

// Fungsi untuk menampilkan menu
function showMenu(message) {
    const menu = `
*${developer.botName} Menu*

*Developer:* ${developer.name}
*Author:* ${developer.author}
*Version:* ${developer.version}
*Status:* ${antilinkStatus ? '🟢 AntiLink ON' : '🔴 AntiLink OFF'} | ${isSelfMode ? '🟢 Self Mode' : '🔴 Public Mode'} | ${bratMode ? '🟢 Brat Mode' : '🔴 Brat Mode'}

*Fitur yang tersedia:*
*PushKontak*
- pushkontak - Menambahkan kontak ke daftar
- pushkontak2 - Menampilkan daftar kontak
- pushkontak3 - Menghapus semua kontak

*JPM*
- jpm - Menyimpan pesan ke JPM
- jpm2 - Menampilkan pesan JPM
- jpmch - Menghapus semua pesan JPM

*Pengaturan*
- antilink on - Mengaktifkan anti-link
- antilink off - Menonaktifkan anti-link
- brat - Mode brat (respon acak ke owner)
- self - Mode self (hanya owner yang bisa menggunakan bot)
- public - Mode public (bot bisa digunakan di group)

Contoh penggunaan: 
- "pushkontak John Doe 628123456789"
- "jpm Pesan penting untuk disimpan"
    `;
    
    message.reply(menu);
}

// ==================== PUSHKONTAK FUNCTIONS ====================

// Fungsi untuk handle pushkontak
function handlePushKontak(message, content) {
    const args = content.split(' ');
    
    if (args[0] === 'pushkontak') {
        if (args.length < 3) {
            return message.reply('Format salah! Gunakan: pushkontak [nama] [nomor]');
        }
        
        const name = args.slice(1, -1).join(' ');
        const number = args[args.length - 1];
        
        // Validasi nomor
        if (!isValidNumber(number)) {
            return message.reply('Nomor tidak valid! Gunakan format 628123456789');
        }
        
        // Tambahkan kontak
        addContact(name, number);
        message.reply(`Kontak ${name} (${number}) berhasil ditambahkan!`);
        
    } else if (args[0] === 'pushkontak2') {
        // Tampilkan daftar kontak
        if (contactsList.length === 0) {
            return message.reply('Daftar kontak kosong!');
        }
        
        let contactListText = '*Daftar Kontak:*\n';
        contactsList.forEach((contact, index) => {
            contactListText += `${index + 1}. ${contact.name} - ${contact.number}\n`;
        });
        
        message.reply(contactListText);
        
    } else if (args[0] === 'pushkontak3') {
        // Hapus semua kontak
        contactsList = [];
        saveContactsData();
        message.reply('Semua kontak berhasil dihapus!');
    }
}

// Fungsi untuk menambahkan kontak
function addContact(name, number) {
    contactsList.push({ name, number });
    saveContactsData();
}

// Fungsi untuk validasi nomor
function isValidNumber(number) {
    const numberRegex = /^(\+62|62|0)8[1-9][0-9]{6,9}$/;
    return numberRegex.test(number);
}

// ==================== JPM FUNCTIONS ====================

// Fungsi untuk handle jpm
function handleJpm(message, content) {
    const args = content.split(' ');
    
    if (args[0] === 'jpm') {
        if (args.length < 2) {
            return message.reply('Format salah! Gunakan: jpm [pesan]');
        }
        
        const jpmMessage = args.slice(1).join(' ');
        jpmData.jpm.push({
            message: jpmMessage,
            timestamp: new Date().toLocaleString('id-ID'),
            from: message.from
        });
        
        saveJpmData();
        message.reply('Pesan berhasil disimpan di JPM!');
        
    } else if (args[0] === 'jpm2') {
        // Tampilkan pesan JPM
        if (jpmData.jpm.length === 0) {
            return message.reply('Tidak ada pesan di JPM!');
        }
        
        let jpmText = '*Daftar Pesan JPM:*\n';
        jpmData.jpm.forEach((item, index) => {
            jpmText += `${index + 1}. ${item.message} (${item.timestamp})\n`;
        });
        
        message.reply(jpmText);
        
    } else if (args[0] === 'jpmch') {
        // Hapus semua pesan JPM
        jpmData.jpm = [];
        saveJpmData();
        message.reply('Semua pesan JPM berhasil dihapus!');
    }
}

// ==================== ANTILINK FUNCTIONS ====================

// Fungsi untuk handle antilink
function handleAntilink(message, content) {
    if (content === 'antilink on') {
        antilinkStatus = true;
        message.reply('Anti-link telah diaktifkan!');
    } else if (content === 'antilink off') {
        antilinkStatus = false;
        message.reply('Anti-link telah dinonaktifkan!');
    }
}

// Fungsi untuk mendeteksi link
function containsLink(text) {
    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+)/gi;
    return linkRegex.test(text);
}

// Fungsi untuk menangani aksi anti-link
function handleAntilinkAction(message) {
    message.reply('❌ Mengirim link tidak diizinkan di group ini!');
    
    // Optional: Beri peringatan atau tindakan lain
    if (message.from.includes('g.us')) {
        // Bisa ditambahkan fungsi untuk memberi peringatan atau mengeluarkan member
    }
}

// ==================== BRAT MODE FUNCTIONS ====================

// Fungsi untuk toggle brat mode
function toggleBratMode(message) {
    bratMode = !bratMode;
    const status = bratMode ? 'diaktifkan' : 'dinonaktifkan';
    message.reply(`Brat mode ${status}! ${bratMode ? 'Saya akan membalas pesan owner dengan respon acak!' : ''}`);
}

// Fungsi untuk handle brat mode
function handleBratMode(message) {
    const randomResponses = [
        "Apa?",
        "Hah?",
        "Lagi sibuk nih!",
        "Nanti dulu ya!",
        "Bisa ulangi?",
        "Wkwkwk!",
        "Hmm...",
        "Oke deh!",
        "Baiklah!",
        "Saya dengar Anda!",
        "Brat mode activated!",
        `${developer.botName} hadir!`
    ];
    
    const randomIndex = Math.floor(Math.random() * randomResponses.length);
    message.reply(randomResponses[randomIndex]);
}

// ==================== TOGGLE MODE FUNCTIONS ====================

// Fungsi untuk toggle self mode
function toggleSelfMode(message) {
    if (!isOwner(message.from)) {
        return message.reply('Hanya owner yang dapat mengubah mode ini!');
    }
    
    isSelfMode = !isSelfMode;
    const status = isSelfMode ? 'diaktifkan' : 'dinonaktifkan';
    message.reply(`Self mode ${status}! ${isSelfMode ? 'Hanya owner yang dapat menggunakan bot.' : 'Bot dapat digunakan oleh semua orang.'}`);
}

// Fungsi untuk toggle public mode
function togglePublicMode(message) {
    if (!isOwner(message.from)) {
        return message.reply('Hanya owner yang dapat mengubah mode ini!');
    }
    
    isPublicMode = !isPublicMode;
    const status = isPublicMode ? 'diaktifkan' : 'dinonaktifkan';
    message.reply(`Public mode ${status}! ${isPublicMode ? 'Bot dapat digunakan di group.' : 'Bot hanya dapat digunakan di chat pribadi.'}`);
}

// ==================== DATA MANAGEMENT ====================

// Fungsi untuk menyimpan data kontak
function saveContactsData() {
    try {
        fs.writeFileSync('./contacts.json', JSON.stringify(contactsList, null, 2));
    } catch (error) {
        console.error('Error saving contacts data:', error);
    }
}

// Fungsi untuk memuat data kontak
function loadContactsData() {
    try {
        if (fs.existsSync('./contacts.json')) {
            const data = fs.readFileSync('./contacts.json');
            contactsList = JSON.parse(data);
        }
    } catch (error) {
        console.error('Error loading contacts data:', error);
    }
}

// Fungsi untuk menyimpan data JPM
function saveJpmData() {
    try {
        fs.writeFileSync('./jpm.json', JSON.stringify(jpmData, null, 2));
    } catch (error) {
        console.error('Error saving JPM data:', error);
    }
}

// Fungsi untuk memuat data JPM
function loadJpmData() {
    try {
        if (fs.existsSync('./jpm.json')) {
            const data = fs.readFileSync('./jpm.json');
            jpmData = JSON.parse(data);
        }
    } catch (error) {
        console.error('Error loading JPM data:', error);
    }
}

// Inisialisasi client
client.initialize();