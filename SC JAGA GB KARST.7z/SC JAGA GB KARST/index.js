const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');

// Informasi Developer & Bot
const developer = {
    name: "KarSatoru Developer",
    author: "KarSatoru Team",
    botName: "KarSatoru",
    version: "1.0.0"
};

// Inisialisasi Client
const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});

// Variabel untuk menyimpan status
let antilinkStatus = false;
let isSelfMode = false;
let isPublicMode = true;
let bratMode = false;
let contactsList = [];
let jpmData = {
    jpm: [],
    jpm2: [],
    jpmch: []
};

// Event ketika QR Code diterima
client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
    console.log('QR Code received, scan dengan WhatsApp Anda!');
});

// Event ketika client ready
client.on('ready', () => {
    console.log(`${developer.botName} is ready!`);
    console.log(`Developer: ${developer.name}`);
    console.log(`Author: ${developer.author}`);
    loadContactsData(); // Memuat data kontak saat bot ready
});

// Event ketika menerima pesan
client.on('message', async (message) => {
    const content = message.body.toLowerCase();
    const sender = message.from;
    
    // Cek jika mode self dan pengirim bukan owner
    if (isSelfMode && !isOwner(sender)) {
        return;
    }
    
    // Cek jika mode public dinonaktifkan
    if (!isPublicMode && !message.from.includes('g.us')) {
        return;
    }
    
    // Command handler
    if (content.startsWith('.karmenu')) {
        showMenu(message);
    } else if (content.startsWith('pushkontak')) {
        handlePushKontak(message, content);
    } else if (content.startsWith('jpm')) {
        handleJpm(message, content);
    } else if (content.startsWith('antilink')) {
        handleAntilink(message, content);
    } else if (content === 'brat') {
        toggleBratMode(message);
    } else if (content === 'self') {
        toggleSelfMode(message);
    } else if (content === 'public') {
        togglePublicMode(message);
    }
    
    // Anti-link functionality
    if (antilinkStatus && containsLink(content) && !message.fromMe && message.from.includes('g.us')) {
        handleAntilinkAction(message);
    }
    
    // Brat mode functionality
    if (bratMode && !message.fromMe && isOwner(sender)) {
        handleBratMode(message);
    }
});
